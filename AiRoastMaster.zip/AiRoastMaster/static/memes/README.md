# Meme templates will be stored here
