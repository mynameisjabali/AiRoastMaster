import os
import random
import logging
import json
import uuid
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room

# Import our modular components
from config import Config, ACHIEVEMENTS, MEME_TEMPLATES, SUPPORTED_LANGUAGES
from roast_engine import RoastEngine
from persona_profiles import get_persona_list

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Enable CORS
CORS(app)

# Enhanced roast categories and keywords
roast_categories = {
    'developer': ['developer', 'code', 'coding', 'software', 'engineer', 'programming', 'bug', 'debug', 'python', 'javascript', 'tech', 'computer', 'laptop', 'github', 'stack overflow', 'framework', 'backend', 'frontend', 'api', 'database'],
    'cat_lover': ['cat', 'kitten', 'feline', 'meow', 'purr', 'cat lady', 'cat person', 'kitty', 'tabby', 'persian', 'siamese', 'pet', 'litter box'],
    'nerdy': ['smart', 'nerd', 'genius', 'iq', 'science', 'math', 'physics', 'chemistry', 'intellectual', 'book', 'reading', 'study', 'academic', 'research', 'phd', 'doctorate', 'quantum'],
    'gamer': ['game', 'gaming', 'gamer', 'fortnite', 'controller', 'keyboard', 'xbox', 'playstation', 'nintendo', 'twitch', 'stream', 'fps', 'mmo', 'rpg', 'console', 'pc gaming', 'esports'],
    'gym': ['gym', 'workout', 'fitness', 'muscle', 'protein', 'gains', 'lifting', 'bodybuilding', 'crossfit', 'cardio', 'abs', 'biceps', 'shredded', 'swole', 'alpha', 'beast mode', 'deadlift', 'squat'],
    'student': ['student', 'college', 'university', 'exam', 'homework', 'study', 'class', 'semester', 'grade', 'professor', 'dorm', 'campus', 'major', 'degree', 'graduate', 'tuition'],
    'boring': ['average', 'normal', 'ordinary', 'basic', 'nothing special', 'regular', 'typical', 'common', 'plain', 'vanilla', 'mediocre', 'bland', 'unremarkable', 'standard'],
    'vain': ['attractive', 'pretty', 'beautiful', 'hot', 'gorgeous', 'handsome', 'model', 'selfie', 'instagram', 'mirror', 'makeup', 'fashion', 'style', 'looks', 'appearance', 'influencer'],
    'crypto': ['crypto', 'bitcoin', 'ethereum', 'blockchain', 'nft', 'defi', 'hodl', 'diamond hands', 'to the moon', 'web3', 'metaverse', 'mining', 'wallet'],
    'hipster': ['hipster', 'artisan', 'craft beer', 'vinyl', 'vintage', 'organic', 'sustainable', 'fair trade', 'local', 'indie', 'alternative', 'ironic'],
    'vegan': ['vegan', 'plant based', 'vegetarian', 'tofu', 'quinoa', 'kale', 'almond milk', 'ethical', 'cruelty free', 'meat free', 'dairy free'],
    'ai': ['ai', 'artificial intelligence', 'machine learning', 'chatgpt', 'openai', 'neural network', 'algorithm', 'automation', 'robot', 'singularity']
}

# Expanded brutal category-specific roasts
brutal_roasts = {
    'developer': [
        "Your code runs about as smoothly as a broken shopping cart with three wheels.",
        "You're the reason Stack Overflow has a downvote button.",
        "Your debugging skills are like your social life - non-existent and full of errors.",
        "You write code like you're trying to confuse future you on purpose.",
        "Your GitHub contributions look like a failed EKG reading.",
        "You're the human equivalent of a syntax error that somehow passed code review.",
        "Your programming skills peaked at 'Hello World' and it's been downhill since.",
        "You code like you're allergic to documentation and best practices."
    ],
    'cat_lover': [
        "You and your cats are locked in a codependent relationship that even therapists won't touch.",
        "Your cats judge you harder than any human ever could, and honestly, they're right.",
        "You're living proof that crazy cat person isn't just a stereotype, it's a lifestyle choice.",
        "Your cats are plotting your demise while you're busy posting their photos online.",
        "You've replaced human connection with feline indifference, and somehow still lost.",
        "Your cats have more personality than you do, and they literally sleep 16 hours a day.",
        "You're the reason cat cafés exist - nobody else wants to deal with your obsession.",
        "Your dating profile probably has more cat photos than selfies, which explains everything."
    ],
    'nerdy': [
        "You're so smart you calculated exactly how lonely you'd be and decided to embrace it.",
        "Your IQ is higher than your social credit score, which isn't saying much.",
        "You know everything about quantum physics but nothing about human interaction.",
        "You're like a walking Wikipedia with the charisma of a dial-up modem.",
        "Your brain is a supercomputer running on the social skills of a potato.",
        "You're proof that intelligence and wisdom are completely different stats.",
        "You can solve complex equations but can't figure out why nobody invites you to parties.",
        "Your intellect is impressive, your personality is a rounding error."
    ],
    'gamer': [
        "Your K/D ratio in games is higher than your real-life achievement count.",
        "You've mastered every boss fight except the one called 'getting a date.'",
        "Your gaming chair has seen more action than your social calendar.",
        "You're speedrunning through life and somehow still coming in last place.",
        "Your respawn time in games is faster than your response time to texts.",
        "You've unlocked every achievement except 'touching grass' and 'meaningful relationships.'",
        "Your controller gets more hand-holding than you do.",
        "You're the final boss of disappointment that nobody wants to face."
    ],
    'gym': [
        "You lift weights but can't lift your own standards above the gym floor.",
        "Your muscles are bigger than your personality, which isn't difficult.",
        "You're shredded physically but your emotional intelligence needs serious bulking.",
        "All those gains and you still can't gain the respect of anyone outside the gym.",
        "You count macros better than you count meaningful relationships.",
        "Your protein intake is higher than your IQ, and that's saying something.",
        "You're swole on the outside but your soul needs a serious workout.",
        "You bench your body weight but can't carry a conversation to save your life."
    ],
    'student': [
        "You're failing at life harder than you failed your last midterm.",
        "Your GPA is higher than your chances of success, and that's concerning.",
        "You're studying everything except how to be an interesting human being.",
        "Your student loans will outlive your career prospects.",
        "You're getting a degree in disappointment with a minor in regret.",
        "Your academic achievements are inversely proportional to your life skills.",
        "You're cramming for exams but can't even cram personality into conversations.",
        "Your graduation will be less of a celebration and more of a wake for your potential."
    ],
    'boring': [
        "You're so unremarkable that even your own reflection falls asleep.",
        "You're the human equivalent of beige paint watching grass grow.",
        "Your personality has the excitement level of a tax document written in Comic Sans.",
        "You're so bland that vanilla ice cream considers you basic.",
        "You're the reason people invented the phrase 'mind-numbingly dull.'",
        "Your life story would cure insomnia better than any medication.",
        "You're aggressively average in a way that defies the laws of statistics.",
        "You make watching paint dry seem like an extreme sport."
    ],
    'vain': [
        "You're in love with your reflection, but it's definitely not mutual.",
        "Your selfie game is strong but your self-awareness game is non-existent.",
        "You're so vain you probably think this roast is about you... it is.",
        "Your beauty is only skin deep, which explains why you're so shallow.",
        "You spend more time looking at yourself than anyone else ever will.",
        "Your mirror works overtime and deserves hazard pay.",
        "You're proof that pretty faces can house absolutely empty minds.",
        "You're like a beautiful book with blank pages - nice cover, zero content."
    ],
    'crypto': [
        "You're hodling onto your delusions harder than your worthless altcoins.",
        "Your portfolio crashed harder than your social life did.",
        "You're the human embodiment of a pump and dump scheme.",
        "Diamond hands, paper personality.",
        "You're buying the dip on everything except self-improvement."
    ],
    'hipster': [
        "You were pretentious before it was cool, which ironically makes you mainstream.",
        "Your personality is as authentic as your 'vintage' clothes from Urban Outfitters.",
        "You're the human equivalent of an overpriced avocado toast.",
        "Your irony is so thick it's become unironically sincere.",
        "You're not unique, you're just expensive and insufferable."
    ],
    'vegan': [
        "You tell people you're vegan more often than you actually eat vegetables.",
        "Your moral superiority complex has more calories than your meals.",
        "You're saving animals but can't save a conversation.",
        "Your personality is as bland as your unseasoned quinoa.",
        "You're proof that eating plants doesn't make you grow as a person."
    ],
    'ai': [
        "You're obsessed with artificial intelligence because you lack the natural kind.",
        "ChatGPT has more personality than you do, and it's literally code.",
        "You're training models but can't train yourself to be interesting.",
        "Your algorithm for social interaction needs serious debugging.",
        "You're worried about AI taking over, but it already has more emotional intelligence than you."
    ],
    'default': [
        "You're the participation trophy of human beings.",
        "If mediocrity was an Olympic sport, you'd win bronze and be proud of it.",
        "You're living proof that evolution sometimes goes in reverse.",
        "You have the energy of a dead phone battery on a Monday morning.",
        "You're the human equivalent of a software update nobody asked for.",
        "You're so forgettable that you probably introduce yourself twice at the same party.",
        "You're the reason aliens don't visit Earth anymore.",
        "You're like a pop-up ad in human form - annoying and easily ignored."
    ]
}

# Roast personas with different styles
roast_personas = {
    'british': {
        'name': '💂 British Sarcasm',
        'prefix': 'I say, old chap, ',
        'suffix': ' Cheerio!',
        'replacements': {'terrible': 'absolutely dreadful', 'stupid': 'rather dim', 'bad': 'quite ghastly'}
    },
    'tiktoker': {
        'name': '🧢 Savage TikToker', 
        'prefix': 'No cap, ',
        'suffix': ' This ain\'t it chief! 💀',
        'replacements': {'terrible': 'mid', 'stupid': 'brain dead', 'bad': 'trash'}
    },
    'professor': {
        'name': '🎓 Condescending Professor',
        'prefix': 'After careful academic analysis, ',
        'suffix': ' Class dismissed.',
        'replacements': {'terrible': 'intellectually bankrupt', 'stupid': 'academically challenged', 'bad': 'pedagogically concerning'}
    },
    'psychopath': {
        'name': '💀 Deadpan Psychopath',
        'prefix': 'Interesting. ',
        'suffix': ' How... fascinating.',
        'replacements': {'terrible': 'concerning', 'stupid': 'intellectually vacant', 'bad': 'deeply troubling'}
    },
    'wholesome': {
        'name': '👶 Wholesome but Disappointed',
        'prefix': 'Oh sweetie, ',
        'suffix': ' Bless your heart.',
        'replacements': {'terrible': 'challenging', 'stupid': 'special', 'bad': 'unique'}
    }
}

# Surprise roast descriptions for roulette mode
surprise_descriptions = [
    "A crypto day trader with an anime body pillow collection",
    "A vegan crossfit enthusiast who does stand-up comedy",
    "A TikTok influencer studying quantum physics",
    "A cat cafe owner who mines bitcoin in their basement", 
    "A hipster barista writing a novel about AI consciousness",
    "A gym bro who collects vintage Pokemon cards",
    "A philosophy major turned life coach selling NFTs",
    "A yoga instructor with a gaming YouTube channel",
    "A software developer who thinks they're a DJ",
    "A film student who only watches Marvel movies"
]

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/roast', methods=['POST'])
def roast():
    """Generate and return a roast based on user input"""
    try:
        data = request.get_json()
        
        if not data or 'description' not in data:
            return jsonify({'error': 'No description provided'}), 400
        
        description = data['description'].strip()
        persona = data.get('persona', 'british')
        mode = data.get('mode', 'single')
        
        if not description:
            return jsonify({'error': 'Description cannot be empty'}), 400
        
        if mode == 'battle':
            # Battle mode with two descriptions
            description2 = data.get('description2', '').strip()
            if not description2:
                return jsonify({'error': 'Both descriptions required for battle mode'}), 400
            
            roast1 = get_contextual_roast(description, persona)
            roast2 = get_contextual_roast(description2, persona)
            verdict = get_battle_verdict()
            
            app.logger.debug(f"Battle mode: '{description}' vs '{description2}'")
            
            return jsonify({
                'roast1': roast1,
                'roast2': roast2,
                'verdict': verdict,
                'mode': 'battle'
            })
        else:
            # Single roast mode
            generated_roast = get_contextual_roast(description, persona)
            
            app.logger.debug(f"Generated roast for '{description}': {generated_roast}")
            
            return jsonify({'roast': generated_roast, 'mode': 'single'})
    
    except Exception as e:
        app.logger.error(f"Error generating roast: {str(e)}")
        return jsonify({'error': 'Failed to generate roast'}), 500

@app.route('/surprise')
def surprise():
    """Get a random surprise description for roulette mode"""
    try:
        description = random.choice(surprise_descriptions)
        return jsonify({'description': description})
    except Exception as e:
        app.logger.error(f"Error getting surprise description: {str(e)}")
        return jsonify({'error': 'Failed to get surprise description'}), 500

@app.route('/rate', methods=['POST'])
def rate_roast():
    """Rate a roast as brutal for the leaderboard"""
    try:
        data = request.get_json()
        roast = data.get('roast', '').strip()
        description = data.get('description', '').strip()
        
        if not roast or not description:
            return jsonify({'error': 'Missing roast or description'}), 400
        
        # Initialize session leaderboard if not exists
        if 'brutal_leaderboard' not in session:
            session['brutal_leaderboard'] = []
        
        # Add to leaderboard
        entry = {
            'roast': roast,
            'description': description,
            'timestamp': datetime.now().isoformat(),
            'votes': 1
        }
        
        # Check if roast already exists and increment votes
        existing = next((item for item in session['brutal_leaderboard'] if item['roast'] == roast), None)
        if existing:
            existing['votes'] += 1
        else:
            session['brutal_leaderboard'].append(entry)
        
        # Sort by votes and keep top 10
        session['brutal_leaderboard'] = sorted(session['brutal_leaderboard'], 
                                             key=lambda x: x['votes'], reverse=True)[:10]
        session.modified = True
        
        return jsonify({'message': 'Rated successfully', 'votes': existing['votes'] if existing else 1})
    
    except Exception as e:
        app.logger.error(f"Error rating roast: {str(e)}")
        return jsonify({'error': 'Failed to rate roast'}), 500

@app.route('/leaderboard')
def get_leaderboard():
    """Get the current brutal roast leaderboard"""
    try:
        leaderboard = session.get('brutal_leaderboard', [])
        return jsonify({'leaderboard': leaderboard[:5]})  # Return top 5
    except Exception as e:
        app.logger.error(f"Error getting leaderboard: {str(e)}")
        return jsonify({'error': 'Failed to get leaderboard'}), 500

def get_contextual_roast(description, persona='british'):
    """
    Generate a context-aware roast based on user description and persona
    """
    description_lower = description.lower()
    
    # Check for category matches with matched keywords
    matched_categories = []
    matched_keywords = []
    
    for category, keywords in roast_categories.items():
        category_matches = [keyword for keyword in keywords if keyword in description_lower]
        if category_matches:
            matched_categories.append(category)
            matched_keywords.extend(category_matches)
            app.logger.debug(f"Matched category: {category} with keywords: {category_matches}")
    
    # Select roast based on matches
    if matched_categories:
        # If multiple categories match, sometimes combine them
        if len(matched_categories) > 1 and random.random() < 0.3:  # 30% chance to combine
            # Create a brutal combination roast
            category1, category2 = random.sample(matched_categories, 2)
            roast1 = random.choice(brutal_roasts[category1])
            roast2 = random.choice(brutal_roasts[category2])
            roast = f"{roast1} Also, {roast2.lower()}"
            app.logger.debug(f"Combined roasts from categories: {category1} and {category2}")
        else:
            # Single category roast
            chosen_category = random.choice(matched_categories)
            roast = random.choice(brutal_roasts[chosen_category])
            app.logger.debug(f"Using roast from category: {chosen_category}")
    else:
        # Fall back to default roasts
        roast = random.choice(brutal_roasts['default'])
        app.logger.debug("Using default roast (no category matched)")
    
    # Add some variation by occasionally replacing words with synonyms
    roast = add_roast_variation(roast)
    
    # Apply persona styling
    roast = apply_persona_style(roast, persona)
    
    return roast

def apply_persona_style(roast, persona):
    """Apply persona-specific styling to the roast"""
    if persona not in roast_personas:
        persona = 'british'
    
    style = roast_personas[persona]
    
    # Apply word replacements
    for original, replacement in style['replacements'].items():
        roast = roast.replace(original, replacement)
    
    # Add prefix and suffix
    styled_roast = f"{style['prefix']}{roast.lower()}{style['suffix']}"
    
    return styled_roast

def get_battle_verdict():
    """Get a random battle verdict"""
    verdicts = [
        "Verdict: Humanity loses.",
        "Winner: The void of existence.",
        "Result: Both need therapy.",
        "Conclusion: Darwin was wrong.",
        "Final score: Disappointment - 2, Hope - 0",
        "The real loser? Anyone who had to read this.",
        "Judges' decision: Everyone should apologize.",
        "Outcome: The gene pool needs chlorine."
    ]
    return random.choice(verdicts)

def add_roast_variation(roast):
    """
    Add slight variations to roasts using synonyms
    """
    # Simple synonym replacements (10% chance each)
    variations = {
        'terrible': ['awful', 'horrible', 'atrocious', 'pathetic'],
        'bad': ['terrible', 'awful', 'horrible', 'atrocious'],
        'stupid': ['idiotic', 'moronic', 'brain-dead', 'clueless'],
        'boring': ['dull', 'tedious', 'mind-numbing', 'soul-crushing'],
        'ugly': ['hideous', 'revolting', 'repulsive', 'grotesque'],
        'useless': ['worthless', 'pointless', 'futile', 'hopeless'],
        'pathetic': ['pitiful', 'miserable', 'tragic', 'sad'],
        'annoying': ['irritating', 'infuriating', 'obnoxious', 'insufferable']
    }
    
    for original, replacements in variations.items():
        if original in roast.lower() and random.random() < 0.1:  # 10% chance
            replacement = random.choice(replacements)
            roast = roast.replace(original, replacement)
            break  # Only one replacement per roast
    
    return roast

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
