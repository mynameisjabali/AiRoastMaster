# Modular roast generation engine

import random
import re
import logging
from datetime import datetime
from config import ROAST_CATEGORIES, EASTER_EGG_KEYWORDS
from persona_profiles import apply_persona_style

# Multilingual roast collections
BRUTAL_ROASTS = {
    'en': {
        'developer': [
            "Your code runs about as smoothly as a broken shopping cart with three wheels.",
            "You're the reason Stack Overflow has a downvote button.",
            "Your programming skills are like your debugging process - full of errors and no real solutions.",
            "You write code like you're being paid by the bug.",
            "Your GitHub contributions look like a heart monitor during cardiac arrest.",
            "You're the human equivalent of a missing semicolon.",
            "Your code is so bad, even the compiler is embarrassed.",
            "You make spaghetti code look organized.",
            "Your API documentation is more confusing than IKEA instructions.",
            "You're proof that copy-paste programming has its limits."
        ],
        'cat_lover': [
            "You have more meaningful relationships with cats than humans, and even the cats are judging you.",
            "Your personality is as independent as a cat - which means nobody actually wants to be around you.",
            "You're living proof that crazy cat person isn't just a stereotype, it's a lifestyle choice.",
            "Your cats probably talk about getting a new owner behind your back.",
            "You're the reason cats have nine lives - they need the extra attempts to escape you.",
            "Your dating profile probably says 'cat parent' because 'human failure' was too honest.",
            "Even your cats swipe left on your life choices.",
            "You treat your cats better than you treat yourself, which isn't saying much.",
            "Your litter box has more going on than your social calendar.",
            "You're one cat away from being a documentary subject."
        ],
        'crypto': [
            "You're hodling onto your delusions harder than your worthless altcoins.",
            "Your portfolio crashed harder than your social life did.",
            "You're the human embodiment of a pump and dump scheme.",
            "Diamond hands, paper personality.",
            "You're buying the dip on everything except self-improvement.",
            "Your crypto wallet is emptier than your dating prospects.",
            "You talk about blockchain more than you talk to actual humans.",
            "Your NFT collection is worth less than your self-respect.",
            "You're still waiting for Dogecoin to fund your retirement and personality transplant.",
            "Your investment strategy is as volatile as your emotional stability."
        ],
        'default': [
            "You're the participation trophy of human beings.",
            "If mediocrity was an Olympic sport, you'd win bronze and be proud of it.",
            "You're living proof that evolution sometimes goes in reverse.",
            "You have the energy of a dead phone battery on a Monday morning.",
            "You're the human equivalent of a software update nobody asked for.",
            "You're so forgettable that you probably introduce yourself twice at the same party.",
            "You're the reason aliens don't visit Earth anymore.",
            "You're like a pop-up ad in human form - annoying and easily ignored.",
            "Your life is like a movie - boring, predictable, and everyone's waiting for it to end.",
            "You're the human equivalent of elevator music."
        ]
    },
    'es': {
        'developer': [
            "Tu código funciona tan suavemente como un carrito de compras roto con tres ruedas.",
            "Eres la razón por la que Stack Overflow tiene un botón de voto negativo.",
            "Tus habilidades de programación son como tu proceso de depuración: lleno de errores y sin soluciones reales."
        ],
        'default': [
            "Eres el trofeo de participación de los seres humanos.",
            "Si la mediocridad fuera un deporte olímpico, ganarías el bronce y estarías orgulloso.",
            "Eres la prueba viviente de que la evolución a veces va en reversa."
        ]
    }
}

# Story mode templates
STORY_TEMPLATES = [
    {
        'setup': "It started when you said: '{description}'",
        'middle': "Then you {action}.",
        'punchline': "And the rest is history: {conclusion}."
    },
    {
        'setup': "Chapter 1: You thought '{description}' was impressive.",
        'middle': "Chapter 2: Reality entered the chat.",
        'punchline': "Chapter 3: {conclusion}. The End."
    },
    {
        'setup': "Once upon a time, someone said '{description}'",
        'middle': "Plot twist: they were serious.",
        'punchline': "Moral of the story: {conclusion}."
    }
]

STORY_ACTIONS = [
    "opened your mouth again",
    "doubled down on that energy",
    "thought you were the main character",
    "forgot mirrors exist",
    "checked your bank account",
    "looked in the mirror",
    "posted it on social media",
    "asked for validation"
]

STORY_CONCLUSIONS = [
    "complete and utter failure",
    "nobody was surprised",
    "the universe cringed",
    "second-hand embarrassment for everyone",
    "a masterclass in delusion",
    "exactly what we expected",
    "a cautionary tale",
    "proof that hope is overrated"
]

class RoastEngine:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def detect_categories(self, description):
        """Detect roast categories from user description"""
        description_lower = description.lower()
        matched_categories = []
        matched_keywords = []
        
        for category, keywords in ROAST_CATEGORIES.items():
            category_matches = [keyword for keyword in keywords if keyword in description_lower]
            if category_matches:
                matched_categories.append(category)
                matched_keywords.extend(category_matches)
                self.logger.debug(f"Matched category: {category} with keywords: {category_matches}")
        
        return matched_categories, matched_keywords
    
    def check_easter_eggs(self, description):
        """Check for easter egg keywords and return special roast"""
        description_lower = description.lower()
        for keyword, special_roast in EASTER_EGG_KEYWORDS.items():
            if keyword in description_lower:
                self.logger.debug(f"Easter egg triggered: {keyword}")
                return special_roast
        return None
    
    def generate_contextual_roast(self, description, persona='british', language='en', mode='single'):
        """Generate a context-aware roast based on user description"""
        # Check for easter eggs first
        easter_egg = self.check_easter_eggs(description)
        if easter_egg:
            return apply_persona_style(easter_egg, persona, language)
        
        # Detect categories
        matched_categories, matched_keywords = self.detect_categories(description)
        
        # Get appropriate roast collection
        roast_collection = BRUTAL_ROASTS.get(language, BRUTAL_ROASTS['en'])
        
        # Select roast based on matches
        if matched_categories:
            # If multiple categories match, sometimes combine them
            if len(matched_categories) > 1 and random.random() < 0.3:  # 30% chance to combine
                category1, category2 = random.sample(matched_categories, 2)
                roast1 = random.choice(roast_collection.get(category1, roast_collection['default']))
                roast2 = random.choice(roast_collection.get(category2, roast_collection['default']))
                roast = f"{roast1} Also, {roast2.lower()}"
                self.logger.debug(f"Combined roasts from categories: {category1} and {category2}")
            else:
                # Single category roast
                chosen_category = random.choice(matched_categories)
                roast = random.choice(roast_collection.get(chosen_category, roast_collection['default']))
                self.logger.debug(f"Using roast from category: {chosen_category}")
        else:
            # Fall back to default roasts
            roast = random.choice(roast_collection['default'])
            self.logger.debug("Using default roast (no category matched)")
        
        # Add variation
        roast = self.add_roast_variation(roast)
        
        # Apply persona styling
        roast = apply_persona_style(roast, persona, language)
        
        return roast
    
    def generate_story_roast(self, description, persona='british', language='en'):
        """Generate a multi-part story roast"""
        template = random.choice(STORY_TEMPLATES)
        action = random.choice(STORY_ACTIONS)
        conclusion = random.choice(STORY_CONCLUSIONS)
        
        parts = [
            template['setup'].format(description=description),
            template['middle'].format(action=action),
            template['punchline'].format(conclusion=conclusion)
        ]
        
        # Apply persona to each part
        styled_parts = [apply_persona_style(part, persona, language) for part in parts]
        
        return styled_parts
    
    def add_roast_variation(self, roast):
        """Add slight variations to roasts using synonyms"""
        synonyms = {
            'terrible': ['awful', 'horrible', 'dreadful', 'pathetic'],
            'stupid': ['dumb', 'foolish', 'senseless', 'mindless'],
            'bad': ['poor', 'lousy', 'crappy', 'weak'],
            'ugly': ['hideous', 'repulsive', 'ghastly', 'revolting'],
            'boring': ['dull', 'tedious', 'monotonous', 'mind-numbing']
        }
        
        for original, replacements in synonyms.items():
            if original in roast and random.random() < 0.3:  # 30% chance to replace
                roast = roast.replace(original, random.choice(replacements))
        
        return roast
    
    def generate_battle_verdict(self):
        """Generate a battle verdict"""
        verdicts = [
            "Verdict: Humanity loses.",
            "Winner: The void of existence.",
            "Result: Both need therapy.",
            "Conclusion: Darwin was wrong.",
            "Final score: Disappointment - 2, Hope - 0",
            "The real loser? Anyone who had to read this.",
            "Judges' decision: Everyone should apologize.",
            "Outcome: The gene pool needs chlorine.",
            "Verdict: Nobody wins when everybody's a disaster.",
            "Result: This is why aliens don't visit Earth."
        ]
        return random.choice(verdicts)
    
    def validate_custom_roast(self, roast_text):
        """Validate user-submitted custom roast"""
        # Basic validation
        if len(roast_text) < 10:
            return False, "Roast too short (minimum 10 characters)"
        
        if len(roast_text) > 500:
            return False, "Roast too long (maximum 500 characters)"
        
        # Simple profanity filter (basic implementation)
        banned_words = ['fuck', 'shit', 'damn', 'bitch', 'asshole', 'cunt']  # Basic list
        for word in banned_words:
            if word in roast_text.lower():
                return False, f"Contains inappropriate content: {word}"
        
        # Check for spam patterns
        if len(set(roast_text.lower().split())) < 3:
            return False, "Roast appears to be spam or repetitive"
        
        return True, "Roast approved"
    
    def get_roast_debug_info(self, description, persona, language, matched_categories, matched_keywords, roast):
        """Generate debug information for developer mode"""
        return {
            'input': description,
            'persona': persona,
            'language': language,
            'detected_categories': matched_categories,
            'matched_keywords': matched_keywords,
            'final_roast': roast,
            'timestamp': datetime.now().isoformat(),
            'easter_egg_checked': self.check_easter_eggs(description) is not None
        }