import os
import random
import logging
import json
import uuid
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room

# Import our modular components
from config import Config, ACHIEVEMENTS, MEME_TEMPLATES, SUPPORTED_LANGUAGES
from roast_engine import RoastEngine
from persona_profiles import get_persona_list

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Enable CORS and SocketIO
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Initialize roast engine
roast_engine = RoastEngine()

# Global storage for real-time features
public_roasts = []
leaderboard = []
custom_roasts = []
user_stats = {}

# Surprise descriptions for roulette mode
surprise_descriptions = [
    "A yoga instructor with a gaming YouTube channel and 3 cats",
    "A cryptocurrency day trader who does CrossFit and is vegan",
    "A philosophy PhD student working as a barista with a TikTok addiction",
    "A freelance graphic designer who collects vintage vinyl and practices meditation",
    "A software engineer who makes artisanal sourdough bread and owns 15 houseplants",
    "A life coach who streams on Twitch and has strong opinions about pineapple on pizza",
    "A sustainable fashion influencer with a side hustle selling handmade candles",
    "A data scientist turned food blogger with commitment issues",
    "A personal trainer who writes poetry and exclusively dates through dating apps",
    "A UX designer obsessed with astrology and true crime podcasts"
]

@app.route('/')
def index():
    """Render the main page"""
    debug_mode = request.args.get('debug', '0') == '1'
    language = request.args.get('lang', 'en')
    return render_template('index.html', 
                         debug_mode=debug_mode, 
                         language=language,
                         personas=get_persona_list(language),
                         supported_languages=SUPPORTED_LANGUAGES)

@app.route('/roasts')
def public_roasts_page():
    """Show public roasts page"""
    return render_template('roasts.html')

@app.route('/builder')
def roast_builder():
    """Custom roast builder page"""
    return render_template('builder.html')

@app.route('/api/roast', methods=['POST'])
def api_roast():
    """API endpoint for third-party roast generation"""
    try:
        data = request.get_json()
        description = data.get('description', '').strip()
        persona = data.get('persona', 'british')
        language = data.get('language', 'en')
        
        if not description:
            return jsonify({'error': 'Description required'}), 400
            
        roast = roast_engine.generate_contextual_roast(description, persona, language)
        
        return jsonify({
            'roast': roast,
            'persona': persona,
            'language': language,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/roast', methods=['POST'])
def roast():
    """Generate and return a roast based on user input"""
    try:
        data = request.get_json()
        description = data.get('description', '').strip()
        description2 = data.get('description2', '').strip()
        persona = data.get('persona', 'british')
        language = data.get('language', 'en')
        mode = data.get('mode', 'single')
        make_public = data.get('make_public', False)
        
        debug_mode = request.args.get('debug', '0') == '1'
        
        if not description:
            return jsonify({'error': 'Please provide a description!'}), 400
        
        # Update user stats
        session_id = session.get('session_id', str(uuid.uuid4()))
        session['session_id'] = session_id
        
        if session_id not in user_stats:
            user_stats[session_id] = {'roasts_generated': 0, 'battles_won': 0, 'achievements': []}
        
        user_stats[session_id]['roasts_generated'] += 1
        
        if mode == 'battle':
            if not description2:
                return jsonify({'error': 'Please provide both fighter descriptions!'}), 400
            
            roast1 = roast_engine.generate_contextual_roast(description, persona, language)
            roast2 = roast_engine.generate_contextual_roast(description2, persona, language)
            verdict = roast_engine.generate_battle_verdict()
            
            app.logger.debug(f"Battle mode: '{description}' vs '{description2}'")
            
            result = {
                'roast1': roast1,
                'roast2': roast2,
                'verdict': verdict,
                'mode': 'battle'
            }
            
            # Add to public roasts if requested
            if make_public:
                public_roasts.insert(0, {
                    'description': f"{description} vs {description2}",
                    'roast': f"Battle: {verdict}",
                    'persona': persona,
                    'language': language,
                    'timestamp': datetime.now().isoformat(),
                    'votes': 0,
                    'id': str(uuid.uuid4())
                })
                # Keep only last 50 public roasts
                if len(public_roasts) > 50:
                    public_roasts.pop()
                
                # Broadcast to all clients
                socketio.emit('new_public_roast', public_roasts[0])
            
        elif mode == 'story':
            story_parts = roast_engine.generate_story_roast(description, persona, language)
            result = {
                'story_parts': story_parts,
                'mode': 'story'
            }
        else:
            # Single roast mode
            roast = roast_engine.generate_contextual_roast(description, persona, language)
            
            app.logger.debug(f"Generated roast for '{description}': {roast}")
            
            result = {
                'roast': roast,
                'description': description,
                'persona': persona,
                'language': language
            }
            
            # Add to public roasts if requested
            if make_public:
                public_roasts.insert(0, {
                    'description': description,
                    'roast': roast,
                    'persona': persona,
                    'language': language,
                    'timestamp': datetime.now().isoformat(),
                    'votes': 0,
                    'id': str(uuid.uuid4())
                })
                # Keep only last 50 public roasts
                if len(public_roasts) > 50:
                    public_roasts.pop()
                
                # Broadcast to all clients
                socketio.emit('new_public_roast', public_roasts[0])
        
        # Check for achievements
        achievements = check_achievements(session_id)
        if achievements:
            result['new_achievements'] = achievements
        
        # Add debug info if requested
        if debug_mode:
            matched_categories, matched_keywords = roast_engine.detect_categories(description)
            result['debug'] = roast_engine.get_roast_debug_info(
                description, persona, language, matched_categories, matched_keywords, 
                result.get('roast', 'N/A')
            )
        
        return jsonify(result)
        
    except Exception as e:
        app.logger.error(f"Error generating roast: {str(e)}")
        return jsonify({'error': 'Failed to generate roast. Please try again.'}), 500

@app.route('/surprise')
def surprise():
    """Get a random surprise description for roulette mode"""
    try:
        description = random.choice(surprise_descriptions)
        return jsonify({'description': description})
    except Exception as e:
        app.logger.error(f"Error getting surprise: {str(e)}")
        return jsonify({'error': 'Failed to get surprise description.'}), 500

@app.route('/rate', methods=['POST'])
def rate_roast():
    """Rate a roast as brutal for the leaderboard"""
    try:
        data = request.get_json()
        roast = data.get('roast', '')
        description = data.get('description', '')
        
        if not roast or not description:
            return jsonify({'error': 'Missing roast or description'}), 400
        
        # Find existing entry or create new one
        existing_entry = None
        for entry in leaderboard:
            if entry['roast'] == roast and entry['description'] == description:
                existing_entry = entry
                break
        
        if existing_entry:
            existing_entry['votes'] += 1
            votes = existing_entry['votes']
        else:
            # Create new leaderboard entry
            new_entry = {
                'roast': roast,
                'description': description,
                'votes': 1,
                'timestamp': datetime.now().isoformat(),
                'id': str(uuid.uuid4())
            }
            leaderboard.append(new_entry)
            votes = 1
        
        # Sort leaderboard by votes (descending)
        leaderboard.sort(key=lambda x: x['votes'], reverse=True)
        
        # Keep only top 20
        if len(leaderboard) > 20:
            leaderboard.pop()
        
        # Broadcast updated leaderboard
        socketio.emit('leaderboard_update', {'leaderboard': leaderboard[:10]})
        
        return jsonify({'success': True, 'votes': votes})
        
    except Exception as e:
        app.logger.error(f"Error rating roast: {str(e)}")
        return jsonify({'error': 'Failed to rate roast.'}), 500

@app.route('/leaderboard')
def get_leaderboard():
    """Get the current brutal roast leaderboard"""
    try:
        return jsonify({'leaderboard': leaderboard[:10]})
    except Exception as e:
        app.logger.error(f"Error getting leaderboard: {str(e)}")
        return jsonify({'error': 'Failed to get leaderboard.'}), 500

@app.route('/api/public_roasts')
def get_public_roasts():
    """Get public roasts"""
    try:
        return jsonify({'roasts': public_roasts[:20]})
    except Exception as e:
        return jsonify({'error': 'Failed to get public roasts.'}), 500

@app.route('/submit_custom_roast', methods=['POST'])
def submit_custom_roast():
    """Submit a custom roast template"""
    try:
        data = request.get_json()
        roast_text = data.get('roast_text', '').strip()
        category = data.get('category', 'default')
        author = data.get('author', 'Anonymous').strip()[:50]  # Limit author name
        
        # Validate the roast
        is_valid, message = roast_engine.validate_custom_roast(roast_text)
        
        if not is_valid:
            return jsonify({'error': message}), 400
        
        # Add to custom roasts collection
        custom_roast = {
            'text': roast_text,
            'category': category,
            'author': author,
            'timestamp': datetime.now().isoformat(),
            'approved': True,  # Auto-approve for demo (in production, would need moderation)
            'id': str(uuid.uuid4())
        }
        
        custom_roasts.append(custom_roast)
        
        # Keep only last 100 custom roasts
        if len(custom_roasts) > 100:
            custom_roasts.pop(0)
        
        return jsonify({'success': True, 'message': 'Custom roast submitted successfully!'})
        
    except Exception as e:
        app.logger.error(f"Error submitting custom roast: {str(e)}")
        return jsonify({'error': 'Failed to submit custom roast.'}), 500

@app.route('/meme_templates')
def get_meme_templates():
    """Get available meme templates"""
    return jsonify({'templates': MEME_TEMPLATES})

def check_achievements(session_id):
    """Check and award achievements"""
    if session_id not in user_stats:
        return []
    
    stats = user_stats[session_id]
    new_achievements = []
    
    # Check roast count achievements
    roast_count = stats['roasts_generated']
    
    achievement_thresholds = [
        (1, 'first_roast'),
        (10, 'roast_veteran'),
        (25, 'ego_slayer'),
        (50, 'emotion_assassin'),
        (100, 'roast_god')
    ]
    
    for threshold, achievement_id in achievement_thresholds:
        if roast_count >= threshold and achievement_id not in stats['achievements']:
            stats['achievements'].append(achievement_id)
            new_achievements.append(ACHIEVEMENTS[achievement_id])
    
    return new_achievements

# WebSocket events
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    join_room('main')
    emit('connected', {'status': 'Connected to AI Roast Me'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    leave_room('main')

@socketio.on('join_leaderboard')
def handle_join_leaderboard():
    """Send current leaderboard to new client"""
    emit('leaderboard_update', {'leaderboard': leaderboard[:10]})

@socketio.on('join_public_roasts')
def handle_join_public_roasts():
    """Send current public roasts to new client"""
    emit('public_roasts_update', {'roasts': public_roasts[:20]})

if __name__ == '__main__':
    # For development only
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)