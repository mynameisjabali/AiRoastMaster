# Persona profiles for different roast styles

# Roast personas with different styles and languages
ROAST_PERSONAS = {
    'british': {
        'name': '💂 British Sarcasm',
        'prefix': 'I say, old chap, ',
        'suffix': ' Cheerio!',
        'replacements': {'terrible': 'absolutely dreadful', 'stupid': 'rather dim', 'bad': 'quite ghastly', 'awful': 'frightfully poor'},
        'tone': 'sophisticated_sarcasm'
    },
    'tiktoker': {
        'name': '🧢 Savage TikToker', 
        'prefix': 'No cap, ',
        'suffix': ' This ain\'t it chief! 💀',
        'replacements': {'terrible': 'mid', 'stupid': 'brain dead', 'bad': 'trash', 'awful': 'cringe'},
        'tone': 'gen_z_savage'
    },
    'professor': {
        'name': '🎓 Condescending Professor',
        'prefix': 'After careful academic analysis, ',
        'suffix': ' Class dismissed.',
        'replacements': {'terrible': 'intellectually bankrupt', 'stupid': 'academically challenged', 'bad': 'pedagogically concerning', 'awful': 'scholastically deficient'},
        'tone': 'academic_condescension'
    },
    'psychopath': {
        'name': '💀 Deadpan Psychopath',
        'prefix': 'Interesting. ',
        'suffix': ' How... fascinating.',
        'replacements': {'terrible': 'concerning', 'stupid': 'intellectually vacant', 'bad': 'deeply troubling', 'awful': 'disturbingly inadequate'},
        'tone': 'cold_analytical'
    },
    'wholesome': {
        'name': '👶 Wholesome but Disappointed',
        'prefix': 'Oh sweetie, ',
        'suffix': ' Bless your heart.',
        'replacements': {'terrible': 'challenging', 'stupid': 'special', 'bad': 'unique', 'awful': 'different'},
        'tone': 'passive_aggressive_nice'
    },
    'millennial': {
        'name': '📱 Millennial Burnout',
        'prefix': 'Like, literally, ',
        'suffix': ' I can\'t even.',
        'replacements': {'terrible': 'problematic', 'stupid': 'low-key dumb', 'bad': 'not it', 'awful': 'super yikes'},
        'tone': 'exhausted_millennial'
    },
    'boomer': {
        'name': '👴 Disappointed Boomer',
        'prefix': 'Back in my day, ',
        'suffix': ' Kids these days!',
        'replacements': {'terrible': 'shameful', 'stupid': 'senseless', 'bad': 'disgraceful', 'awful': 'appalling'},
        'tone': 'generational_disappointment'
    }
}

# Multi-language persona variations
PERSONA_TRANSLATIONS = {
    'es': {
        'british': {
            'name': '💂 Sarcasmo Británico',
            'prefix': 'Escucha, amigo, ',
            'suffix': ' ¡Hasta la vista!'
        },
        'tiktoker': {
            'name': '🧢 TikToker Salvaje',
            'prefix': 'No mames, ',
            'suffix': ' ¡Esto no está bien! 💀'
        }
    },
    'fr': {
        'british': {
            'name': '💂 Sarcasme Britannique',
            'prefix': 'Mon cher ami, ',
            'suffix': ' Au revoir!'
        },
        'tiktoker': {
            'name': '🧢 TikTokeur Sauvage',
            'prefix': 'Franchement, ',
            'suffix': ' C\'est pas ça! 💀'
        }
    }
}

def apply_persona_style(roast, persona='british', language='en'):
    """Apply persona-specific styling to the roast with language support"""
    if language != 'en' and language in PERSONA_TRANSLATIONS:
        if persona in PERSONA_TRANSLATIONS[language]:
            style = PERSONA_TRANSLATIONS[language][persona]
        else:
            style = ROAST_PERSONAS.get(persona, ROAST_PERSONAS['british'])
    else:
        style = ROAST_PERSONAS.get(persona, ROAST_PERSONAS['british'])
    
    # Apply word replacements if available
    if 'replacements' in style:
        for original, replacement in style['replacements'].items():
            roast = roast.replace(original, replacement)
    
    # Add prefix and suffix
    prefix = style.get('prefix', '')
    suffix = style.get('suffix', '')
    styled_roast = f"{prefix}{roast.lower()}{suffix}"
    
    return styled_roast

def get_persona_list(language='en'):
    """Get list of available personas for a language"""
    if language != 'en' and language in PERSONA_TRANSLATIONS:
        translated_personas = {}
        for persona_id, persona_data in ROAST_PERSONAS.items():
            if persona_id in PERSONA_TRANSLATIONS[language]:
                translated_personas[persona_id] = PERSONA_TRANSLATIONS[language][persona_id]
            else:
                translated_personas[persona_id] = persona_data
        return translated_personas
    return ROAST_PERSONAS