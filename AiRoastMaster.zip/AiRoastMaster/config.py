# Configuration and keyword categories for AI Roast Me

import os

# Flask configuration
class Config:
    SECRET_KEY = os.environ.get('SESSION_SECRET', 'dev-secret-key-12345')
    DEBUG = os.environ.get('DEBUG', 'True').lower() == 'true'

# Enhanced roast categories and keywords for multiple languages
ROAST_CATEGORIES = {
    'developer': ['developer', 'code', 'coding', 'software', 'engineer', 'programming', 'bug', 'debug', 'python', 'javascript', 'tech', 'computer', 'laptop', 'github', 'stack overflow', 'framework', 'backend', 'frontend', 'api', 'database', 'react', 'node', 'docker', 'kubernetes'],
    'cat_lover': ['cat', 'kitten', 'feline', 'meow', 'purr', 'cat lady', 'cat person', 'kitty', 'tabby', 'persian', 'siamese', 'pet', 'litter box', 'whiskers', 'scratching post'],
    'nerdy': ['smart', 'nerd', 'genius', 'iq', 'science', 'math', 'physics', 'chemistry', 'intellectual', 'book', 'reading', 'study', 'academic', 'research', 'phd', 'doctorate', 'quantum', 'theorem', 'hypothesis'],
    'gamer': ['game', 'gaming', 'gamer', 'fortnite', 'controller', 'keyboard', 'xbox', 'playstation', 'nintendo', 'twitch', 'stream', 'fps', 'mmo', 'rpg', 'console', 'pc gaming', 'esports', 'headset', 'lag'],
    'gym': ['gym', 'workout', 'fitness', 'muscle', 'protein', 'gains', 'lifting', 'bodybuilding', 'crossfit', 'cardio', 'abs', 'biceps', 'shredded', 'swole', 'alpha', 'beast mode', 'deadlift', 'squat', 'bench press'],
    'student': ['student', 'college', 'university', 'exam', 'homework', 'study', 'class', 'semester', 'grade', 'professor', 'dorm', 'campus', 'major', 'degree', 'graduate', 'tuition', 'thesis', 'finals'],
    'boring': ['average', 'normal', 'ordinary', 'basic', 'nothing special', 'regular', 'typical', 'common', 'plain', 'vanilla', 'mediocre', 'bland', 'unremarkable', 'standard', 'mainstream'],
    'vain': ['attractive', 'pretty', 'beautiful', 'hot', 'gorgeous', 'handsome', 'model', 'selfie', 'instagram', 'mirror', 'makeup', 'fashion', 'style', 'looks', 'appearance', 'influencer', 'photogenic', 'filter'],
    'crypto': ['crypto', 'bitcoin', 'ethereum', 'blockchain', 'nft', 'defi', 'hodl', 'diamond hands', 'to the moon', 'web3', 'metaverse', 'mining', 'wallet', 'dogecoin', 'satoshi'],
    'hipster': ['hipster', 'artisan', 'craft beer', 'vinyl', 'vintage', 'organic', 'sustainable', 'fair trade', 'local', 'indie', 'alternative', 'ironic', 'kombucha', 'flannel'],
    'vegan': ['vegan', 'plant based', 'vegetarian', 'tofu', 'quinoa', 'kale', 'almond milk', 'ethical', 'cruelty free', 'meat free', 'dairy free', 'hemp', 'spirulina'],
    'ai': ['ai', 'artificial intelligence', 'machine learning', 'chatgpt', 'openai', 'neural network', 'algorithm', 'automation', 'robot', 'singularity', 'llm', 'gpt', 'prompt'],
    'meme': ['meme', 'reddit', 'tiktok', 'viral', 'cringe', 'based', 'sus', 'poggers', 'simp', 'chad', 'karen', 'boomer', 'zoomer', 'millennial']
}

# Easter egg keywords
EASTER_EGG_KEYWORDS = {
    'pineapple on pizza': 'Your food preferences are more controversial than your personality is interesting.',
    'i use bing': 'Using Bing is like voluntarily choosing to be wrong about everything.',
    'crypto millionaire': 'The only thing inflated more than your portfolio is your ego.',
    'tiktok famous': 'Your 15 seconds of fame expired 14 seconds ago.',
    'linkedin influencer': 'You post motivational quotes like they\'re profound wisdom instead of recycled platitudes.'
}

# Achievement system
ACHIEVEMENTS = {
    'first_roast': {'name': 'Roast Virgin', 'description': 'Got your first roast', 'icon': '🔥'},
    'roast_veteran': {'name': 'Certified Toast', 'description': 'Generated 10 roasts', 'icon': '🏆'},
    'ego_slayer': {'name': 'Ego Slayer', 'description': 'Generated 25 roasts', 'icon': '⚔️'},
    'emotion_assassin': {'name': 'Emotion Assassin', 'description': 'Generated 50 roasts', 'icon': '💀'},
    'roast_god': {'name': 'Roast God', 'description': 'Generated 100 roasts', 'icon': '👑'},
    'battle_warrior': {'name': 'Battle Warrior', 'description': 'Won 5 roast battles', 'icon': '🛡️'},
    'surprise_master': {'name': 'Surprise Master', 'description': 'Used surprise mode 10 times', 'icon': '🎰'},
    'voice_actor': {'name': 'Voice Actor', 'description': 'Used TTS 20 times', 'icon': '🎭'},
    'meme_lord': {'name': 'Meme Lord', 'description': 'Generated 10 meme roasts', 'icon': '🐸'},
    'social_butterfly': {'name': 'Social Butterfly', 'description': 'Shared 5 roasts', 'icon': '🦋'}
}

# Supported languages
SUPPORTED_LANGUAGES = {
    'en': 'English',
    'es': 'Español',
    'fr': 'Français',
    'de': 'Deutsch',
    'it': 'Italiano'
}

# Meme templates
MEME_TEMPLATES = {
    'drake': {
        'name': 'Drake Pointing',
        'template': 'drake.jpg',
        'text_positions': [(50, 30), (50, 70)]
    },
    'distracted_boyfriend': {
        'name': 'Distracted Boyfriend',
        'template': 'distracted_boyfriend.jpg',
        'text_positions': [(20, 85), (50, 85), (80, 85)]
    },
    'woman_yelling_cat': {
        'name': 'Woman Yelling at Cat',
        'template': 'woman_yelling_cat.jpg',
        'text_positions': [(25, 85), (75, 85)]
    },
    'expanding_brain': {
        'name': 'Expanding Brain',
        'template': 'expanding_brain.jpg',
        'text_positions': [(50, 20), (50, 40), (50, 60), (50, 80)]
    }
}