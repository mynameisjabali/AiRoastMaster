# Replit.md - AI Roast Me Web App

## Overview

This is an enhanced Flask-based web application that generates humorous "roasts" based on user descriptions. Users input a description of themselves, and the application responds with a randomly selected roast template filled with their input. The app features a modern Bootstrap-styled frontend with JavaScript interactivity, a simple Flask backend, and multiple enhancement features including roast regeneration, clipboard copying, image downloads, session-based history, and sound effects.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Technology**: Vanilla JavaScript with Bootstrap 5 for styling
- **Structure**: Single-page application (SPA) with client-side form handling
- **Styling**: Bootstrap with custom CSS for enhanced visual appeal
- **Responsiveness**: Mobile-first responsive design using Bootstrap grid system

### Backend Architecture
- **Framework**: Flask (Python)
- **Architecture Pattern**: Simple MVC pattern
- **API Design**: RESTful endpoints with JSON responses
- **CORS**: Enabled for cross-origin requests

## Key Components

### Backend Components
1. **Flask Application (`app.py`)**
   - Main application entry point
   - Route handlers for home page and roast generation
   - Static roast templates stored in-memory
   - Environment-based configuration for session secrets

2. **Roast Generation System**
   - Pre-defined roast templates with placeholder substitution
   - Random selection mechanism for variety
   - Template-based approach for consistent roast structure

### Frontend Components
1. **HTML Template (`templates/index.html`)**
   - Bootstrap-based responsive layout with dark theme
   - Form for user input with validation
   - Results display area with action buttons
   - Character counter and input constraints
   - Success toast notifications
   - Collapsible roast history accordion
   - Audio element for sound effects
   - html2canvas integration for image generation

2. **JavaScript (`static/script.js`)**
   - Form submission handling with AJAX
   - Dynamic UI updates and error handling
   - Character counting and input validation
   - Roast regeneration functionality
   - Clipboard copy functionality with fallback
   - Image download using html2canvas
   - Session storage for roast history
   - Audio playback for roast sound effects
   - Toast notifications for user feedback

3. **Styling (`static/style.css`)**
   - Custom CSS enhancements over Bootstrap
   - Interactive button animations and hover effects
   - Gradient text effects and consistent theming
   - Accordion and toast styling
   - Responsive design for mobile devices
   - Pulse animations for interactive elements

4. **Audio Assets (`static/roast.wav`)**
   - Simple tone-based sound effect for roast reveals
   - Automatically plays when roast is generated

## Data Flow

1. **User Input**: User enters description in textarea (max 500 characters)
2. **Client Validation**: JavaScript validates input length and content
3. **API Request**: Frontend sends POST request to `/roast` endpoint with user description
4. **Roast Generation**: Backend randomly selects and populates roast template
5. **Response**: Server returns JSON with generated roast text
6. **Display**: Frontend updates UI to show the roast result with action buttons
7. **Enhancement Features**:
   - **Sound Effect**: Plays roast sound automatically
   - **History Storage**: Saves roast to sessionStorage with timestamp
   - **Action Buttons**: Shows "Roast Again", "Copy", and "Download" options
   - **Regeneration**: Can generate new roasts with same description
   - **Clipboard**: Copies roast text with modern/fallback APIs
   - **Image Export**: Converts roast card to downloadable PNG

## External Dependencies

### Backend Dependencies
- **Flask**: Web framework for Python
- **Flask-CORS**: Cross-Origin Resource Sharing support
- **Python logging**: Built-in logging for debugging

### Frontend Dependencies
- **Bootstrap 5**: UI framework with dark theme (via CDN)
- **Google Fonts (Inter)**: Typography enhancement (via CDN)
- **html2canvas**: Screenshot generation for image downloads (via CDN)
- **Vanilla JavaScript**: Core functionality with modern APIs

## Deployment Strategy

### Environment Configuration
- Session secret configurable via `SESSION_SECRET` environment variable
- Fallback to development secret for local testing
- Debug logging enabled for development

### File Structure
```
/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── templates/
│   └── index.html        # Enhanced HTML template with new features
├── static/
│   ├── style.css         # Enhanced styling with new components
│   ├── script.js         # Enhanced JavaScript with all new features
│   └── roast.wav         # Sound effect for roast reveals
└── pyproject.toml        # Python dependencies
```

### Hosting Requirements
- Python environment with Flask support
- Static file serving capability
- Environment variable support for configuration
- No database required (templates stored in memory)

## Technical Decisions

### Template-Based Roast Generation
- **Problem**: Need to generate varied, humorous responses
- **Solution**: Pre-written templates with placeholder substitution
- **Rationale**: Ensures quality and consistency while allowing for user input integration
- **Pros**: Fast generation, predictable output quality
- **Cons**: Limited variety, requires manual template creation

### In-Memory Storage
- **Problem**: Need to store roast templates
- **Solution**: Python list stored in application memory
- **Rationale**: Simple deployment, fast access, no external dependencies
- **Pros**: No database setup required, instant access
- **Cons**: Templates reset on application restart, not easily editable

### Client-Side Validation
- **Problem**: Need to validate user input
- **Solution**: JavaScript validation with server-side backup
- **Rationale**: Better user experience with immediate feedback
- **Pros**: Responsive UI, reduced server load
- **Cons**: Requires JavaScript enabled, duplicate validation logic

## Recent Changes (July 2025)

### Enhancement Features Added
1. **Roast Regeneration**: "Roast Me Again" button for same description
2. **Clipboard Integration**: Copy roast text with modern/fallback APIs
3. **Image Downloads**: Screenshot roast cards as PNG files using html2canvas
4. **Session History**: Store and display roast history in collapsible accordion
5. **Sound Effects**: Audio feedback when roasts are revealed
6. **Enhanced UI**: Action buttons, toast notifications, improved mobile experience

### Context-Aware Roast Generation Upgrade
7. **Smart Categorization**: AI now analyzes user descriptions to match 12+ categories
8. **Keyword Detection**: 25+ roasts per category (developer, gamer, cat lover, crypto, hipster, vegan, AI, etc.)
9. **Multi-Category Roasts**: 30% chance to combine roasts from multiple detected categories
10. **Synonym Variations**: Dynamic word replacement to add variety to roasts
11. **Keyword Highlighting**: Visual highlighting of detected keywords in user descriptions
12. **Category Display**: Shows detected categories with badges and highlighted input

### Viral-Ready Complete Upgrade
13. **Multiple Roast Personas**: 5 distinct persona styles (British Sarcasm, Savage TikToker, Condescending Professor, Deadpan Psychopath, Wholesome but Disappointed)
14. **Voice Synthesis**: Browser-based text-to-speech for roast playback with voice selection
15. **Battle Mode**: Two-player roast battles with side-by-side comparison and verdicts
16. **Surprise Roulette**: Auto-generated random descriptions for instant viral content
17. **Brutal Leaderboard**: Session-based voting system for top roasts with real-time updates
18. **Enhanced UI/UX**: Professional 3-column layout with sidebar leaderboard and pro tips
19. **Social Sharing Ready**: Open Graph meta tags, downloadable roast images, optimized for viral spread
20. **Advanced Animations**: Gradient text effects, shimmer animations, bounce effects, and loading states
21. **Mobile-First Design**: Fully responsive with touch-optimized controls and collapsible sidebars

### Technical Implementation
- **Session Storage**: JSON-based roast history (max 20 items)
- **Audio Integration**: Simple WAV file generation and playback
- **Image Generation**: html2canvas for screenshot functionality
- **Modern APIs**: Clipboard API with document.execCommand fallback
- **Smart Roast Engine**: Keyword matching across 8 categories with 200+ unique roasts
- **Dynamic Highlighting**: Real-time keyword detection and visual feedback
- **Error Handling**: Comprehensive try-catch blocks for all new features
- **Accessibility**: Alt text for images, ARIA labels for UI elements

### Roast Categories Implemented
- **Developer**: Code, programming, tech-related keywords (API, database, framework)
- **Cat Lover**: Feline, pet-related terms (litter box, tabby, persian)
- **Nerdy**: Intelligence, academic, science keywords (quantum, PhD, research)
- **Gamer**: Gaming, console, streaming terms (esports, Twitch, FPS)
- **Gym**: Fitness, workout, bodybuilding keywords (deadlift, gains, beast mode)
- **Student**: Education, college, academic life (tuition, dorm, semester)
- **Boring**: Basic, average, unremarkable descriptors (vanilla, mediocre)
- **Vain**: Appearance, beauty, self-focused terms (influencer, selfie, mirror)
- **Crypto**: Cryptocurrency and blockchain terms (HODL, diamond hands, Web3)
- **Hipster**: Artisan culture and alternative lifestyle (craft beer, vinyl, organic)
- **Vegan**: Plant-based lifestyle and ethical choices (quinoa, cruelty-free, tofu)
- **AI**: Artificial intelligence and tech obsession (ChatGPT, neural network, algorithm)
- **Default**: Fallback roasts for unmatched descriptions

### Final Ultimate Technical Architecture (July 2025)

**Complete Modular Backend Architecture:**
- **app.py**: Main Flask-SocketIO application with real-time capabilities
- **config.py**: Centralized configuration, categories, achievements, and language support
- **roast_engine.py**: Advanced roast generation with story mode, easter eggs, and multilingual support
- **persona_profiles.py**: 7 distinct persona styles with language translations

**Real-Time Features:**
- **Flask-SocketIO**: Live leaderboard updates and public roast broadcasts
- **WebSocket Integration**: Real-time notifications and community features
- **Public Roast Feed**: Live streaming of community roasts with voting
- **Session Persistence**: Advanced achievement tracking and user statistics

**Complete Feature Set:**
- **13 Ultimate Modes**: Solo, Battle, Story, Surprise, Meme Generation, Custom Builder
- **API Endpoints**: Third-party integration ready with /api/roast
- **Multilingual Support**: 5 languages (EN, ES, FR, DE, IT) with persona translations
- **Achievement System**: 10+ achievements with local storage persistence
- **Developer Tools**: Debug mode with detailed roast generation analytics

**Advanced User Interface:**
- **3 Specialized Pages**: Main app, Public Feed, Custom Builder
- **Real-time Updates**: Live leaderboard, public roasts, achievement notifications
- **Professional Layout**: Navigation links, settings panel, debug console
- **Mobile Optimization**: Fully responsive with touch-optimized controls

**Viral-Ready Features:**
- **Social Sharing**: Twitter integration with hashtags and permalinks
- **Downloadable Content**: Roast images, meme generation templates
- **Community Building**: Public feed, voting system, custom roast submissions
- **Easter Eggs**: Special roasts for viral keywords and phrases